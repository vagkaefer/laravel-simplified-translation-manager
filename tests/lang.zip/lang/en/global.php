<?php

return [

    // English

    'account-setings' => 'Account Setings',
    'client' => 'Client|Clients',
    'configs' => 'Config|Configs',
    'contract' => 'Contract|Contracts',
    'hello' => 'Hello',
    'invoice' => 'Invoice|Invoices',
    'logout' => 'Sign Out',
    'service' => 'Service|Services',


];
