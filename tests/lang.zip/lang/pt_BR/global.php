<?php

return [

    // Português

    'account-setings' => 'Configurações da conta',
    'client' => 'Cliente|Clientes',
    'configs' => 'Configuração|Configurações',
    'contract' => 'Contrato|Contratos',
    'hello' => 'Olá',
    'invoice' => 'Fatura|Faturas',
    'logout' => 'Sair',
    'report' => 'Relatório|Relatórios',
    'service' => 'Serviço|Serviços',


];
