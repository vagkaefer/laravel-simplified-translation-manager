<?php

return [

    // Español

    'account-setings' => 'Configuraciones de la cuenta',
    'client' => 'Cliente|Clientes',
    'contract' => 'Contrato|Contratos',
    'configs' => 'Ajuste|Ajustes',
    'hello' => 'Hola',
    'invoice' => 'Factura|Facturas',
    'logout' => 'Desconectar',
    'service' => 'Servicio|Servicios',

];
